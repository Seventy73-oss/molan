# 墨澜工坊 · 自动写作系统技术文档

> 面向对象：要接手/修改本系统的 agent 或开发者。
> 最后更新：2026-09-10（自动写作全链路 + 进度可见性 + 防跑偏 完成后）
> 服务地址：`http://192.168.31.180:17381/`

---

## 0. 给 agent 的快速上手（TL;DR）

| 你要做的事 | 看哪一节 | 关键约束 |
|---|---|---|
| 改前端按钮/菜单/进度显示 | §6、§7 | 前端注入层是 `glue.js`（原生 DOM），**不是** React bundle |
| 改自动写作流程/提示词 | §5 | 改 `handlers/stream.rs`，必须走 `molan-deploy.ps1` 部署 |
| 改页面样式（分栏/输入框高度） | §7.4 | 走 `web/molan-ui-patch.js` + `index.html` 注入 |
| 新增设置项 | §8.2 | key 命名 `book_<x>__<bookId>`，走 `set_setting` IPC |
| 数据恢复/救火 | §9 | 先备份 `writerx.db*`，再动 |
| 验证改动 | §11 | Playwright 必须用 `domcontentloaded`，**不要用 `networkidle`** |

**三条铁律**：
1. **一切改动都必须在 NAS 上部署并验证**（本地跑不出结果，前端资源在 NAS 的 `/vol2/molan-deploy/web/`）。
2. **前端不能用 React 的 state/路由**——React 不轮询、不暴露 store，所有动态 UI 走 `glue.js` 原生 DOM 注入。
3. **在 MutationObserver 回调里绝不做会再次触发自己的 DOM 改动**——会死循环把页面卡死（§7.3 有完整案例）。

---

## 1. 系统概览

```
┌──────────────────────── NAS (fnOS, 192.168.31.180) ────────────────────────┐
│                                                                            │
│  Docker: molan-rust (network_mode=host, PORT=17381)                        │
│    └─ /vol2/molan-deploy/molan-server   ← Rust 单静态二进制（含前端资源）  │
│         ├─ GET  /             → /vol2/molan-deploy/web/index.html          │
│         ├─ GET  /assets/*     → React 打包产物（cache-control: no-store）   │
│         ├─ GET  /molan-ui-patch.js → 分栏/输入框高度补丁                    │
│         ├─ POST /ipc/<cmd>    → 全部业务命令（NDJSON 流）                  │
│         └─ 内联注入 glue.js   → 全自动写作 UI（原生 DOM）                  │
│                                                                            │
│  /vol2/1000/molan-books/                                                   │
│    ├─ writerx.db (+ -wal, -shm)   SQLite：书/会话/消息/设置/任务          │
│    ├─ books/<bookId>/{设定,细纲,正文,正文待审,参考}/*.md                  │
│    ├─ versions/<bookId>/<group>/<file>/<ts>.json   文件历史快照（救命用）  │
│    └─ trash/<bookId>/*.json                        文件回收站              │
│                                                                            │
│  Docker: molan-builder (rust:1.95-slim, 2 核/3GB) ← 只用来编译            │
└────────────────────────────────────────────────────────────────────────────┘
        ▲                                              ▲
        │ 部署：molan-deploy.ps1（本机 → NAS）         │ 浏览器访问
        │                                              │
   C:\Users\17213\Documents\墨澜工坊\rust\        用户浏览器（就是生产客户端）
```

**技术栈**：Rust（axum 0.7 + rusqlite 0.32 + reqwest + tokio）+ React 19 打包产物 + 原生 DOM 注入层。

**为什么有"原生 DOM 注入层"**：React bundle 是压缩产物、无 source map、不暴露 store、不做轮询。要加功能又不想重新打包 React，就用 `glue.js` 在页面加载时用原生 DOM 往 React 渲染出的容器里插节点。这是本系统最重要的架构决策，改动前务必读完 §7。

---

## 2. 访问与部署

### 2.1 固定信息

| 项 | 值 |
|---|---|
| Web | `http://192.168.31.180:17381/` |
| SSH | `seventy73@192.168.31.180`，plink/pscp 在 `C:\Program Files\PuTTY\` |
| hostkey | `SHA256:AGHIKBhCpIgrR8M1jptWmfNt2H/S1DgaggI7ALaRplg` |
| 容器 | `molan-rust`（network_mode=host） |
| 二进制 | `/vol2/molan-deploy/molan-server`（当前 ~11.75 MB） |
| 数据根 | `/vol2/1000/molan-books/` |
| 部署脚本 | `C:\Users\17213\Documents\墨澜工坊\molan-deploy.ps1` |
| 源码根 | `C:\Users\17213\Documents\墨澜工坊\rust\` |

### 2.2 部署流程（唯一正确姿势）

```powershell
cd 'C:\Users\17213\Documents\墨澜工坊'; .\molan-deploy.ps1
```

1. 打包 `rust/` 源码 → tgz → 上传到 NAS
2. NAS 上 `molan-builder` 容器里增量编译（首次 90s，后续 37~55s）
3. 备份旧二进制 → `molan-server.bak.<YYYYMMDD-HHMMSS>`
4. 重启 `molan-rust` → 健康检查（最多重试若干次）
5. 回滚：`.\molan-deploy.ps1 -Rollback`

**验收信号**（脚本末尾会打印）：
```
[build] ✅ 完成，耗时 37s，产物 11751320 字节
[deploy] ✅ 健康检查通过（第 1 次）
[4/4] 完成 ✅
```

> ⚠️ 脚本最后可能返回 `[exit code: 1]`，这是收尾管道的产物，**不代表失败**。以 "✅ 完成" + "健康检查通过" + 产物字节数为准。

**前端资源**（`/vol2/molan-deploy/web/`）用 `cache-control: no-store`，改完刷新页面即可，无需清缓存。
**`glue.js` 是编译进二进制的**（`rust/crates/molan-server/src/glue.js`），改它必须重新部署。

### 2.3 NAS 上执行命令的正确方式

中文/特殊字符/括号在 plink 单行命令里会被 shell 吃掉。**永远上传脚本文件再执行**：

```powershell
& "C:\Program Files\PuTTY\pscp.exe" -P 22 -pw <pw> -hostkey "<hostkey>" `
  'C:\path\to\script.py' seventy73@192.168.31.180:/tmp/script.py
& "C:\Program Files\PuTTY\plink.exe" -ssh seventy73@192.168.31.180 -P 22 -pw <pw> `
  -hostkey "<hostkey>" -batch 'python3 /tmp/script.py'
```

Python 脚本读 NAS 中文输出时必须 `encoding='utf-8', errors='replace'`（否则 GBK 解码崩溃）。

---

## 3. 代码结构与职责

```
rust/
├─ crates/molan-core/src/
│  ├─ db.rs        SQLite 连接池、exec/q_json 辅助
│  ├─ files.rs     读写书籍文件（read_file/write_file/scan_tree/import_book）
│  │               ★ write_file 会写 versions/ 快照
│  ├─ books.rs     create_book/delete_book/purge_book/回收站
│  └─ deai.rs      ★ 去AI味机器门 score_text()（PASS_SCORE = 32.0）
├─ crates/molan-llm/  模型渠道解析 resolve_agent_channel(db, role)
└─ crates/molan-server/src/
   ├─ main.rs       axum 路由、静态资源、/ipc/<cmd> 入口
   ├─ glue.js       ★ 前端注入层（全自动按钮、菜单、进度卡片、设置页面板）
   └─ handlers/
      ├─ mod.rs     IPC 命令分发（几百个 "cmd" => 分支）
      └─ stream.rs  ★★ 自动写作流水线（本系统核心，3000+ 行）
```

**`handlers/stream.rs` 关键函数地图**：

| 函数/常量 | 作用 |
|---|---|
| `auto_write_start` | 启动任务：写 `auto_task` 行、清日志、起后台 tokio 任务 |
| `auto_write_resume` | 续跑上次未完成任务 |
| `auto_write_stop` | 置 `AUTO_STOP=true`，当前章写完后停 |
| `auto_write_status` | 返回进度 + `logs`（前端轮询用） |
| `auto_write_run` | 主循环：逐章 细纲→正文→审核→去AI味→写入→章后处理 |
| `auto_book_context` | ★ 每章注入的上下文（L0/L0.5/L1/L2 + 一致性红线） |
| `review_and_fix_chapter` | ★ 自动审核 + 发现问题重写一轮 |
| `deai_pass` / `score_text` | 去AI味循环（最多 2 轮） |
| `post_chapter` | 人物表回写、伏笔台账、滚动前情摘要、定期体检 |
| `AUTO_RUN` | 运行态（`Mutex<Option<Value>>`） |
| `AUTO_LOGS` / `AUTO_LOG_BOOK` | ★ 实时进度日志 + 归属书 id |
| `auto_log_clear(book_id)` / `auto_log(ch, step, text)` / `auto_logs_for(book_id)` | 日志读写 |
| `persist_auto_task` | 进度落盘（重启可查可续跑） |

---

## 4. IPC 协议

**端点**：`POST /ipc/<command>`，Body：`{"args":{...}, "options":{...}}`
**响应**：NDJSON，逐行 JSON；最终结果行是 `{"r": <result>}`。

```bash
curl -s -X POST http://127.0.0.1:17381/ipc/auto_write_status \
  -H 'Content-Type: application/json' \
  -d '{"args":{"bookId":"c781b12a-..."}}'
```

### 4.1 自动写作相关命令

| 命令 | args | 说明 |
|---|---|---|
| `auto_write_start` | `{bookId, sessionId, fromCh, toCh, fullAuto}` | `fullAuto=true` → 写 `正文/` 且 `status=approved`；`false` → 写 `正文待审/` 且 `pending` |
| `auto_write_resume` | `{bookId}` | 从上次 `currentCh+1` 续跑 |
| `auto_write_stop` | `{}` | 请求停止 |
| `auto_write_status` | `{bookId}` | 运行中返回内存态；空闲回退查 `auto_task` 最新行。**都带 `logs`** |

`auto_write_status` 返回示例：
```json
{"bookId":"...","taskId":15,"from":1,"to":3,"current":2,"running":true,
 "status":"running","error":"","fullAuto":true,"resumable":false,
 "logs":[{"ts":1788970996342,"ch":1,"step":"start","text":"开始：第1~3章 · 全自动（审核 → 去AI味 → 写入正文）"}]}
```

### 4.2 其它常用命令

| 命令 | 用途 |
|---|---|
| `get_settings` / `set_setting` | 读全部设置 / 写单项（`{key, value}`） |
| `scan_tree` | 返回 `[{dir, files:[{name,...}]}]` 目录树 |
| `read_file` / `write_file` | `{bookId, group, name, content}` |
| `list_messages` | `{sessionId}` 会话消息 |
| `create_book` / `delete_book` / `purge_book` | `purge_book` = 删目录 + `DELETE FROM books`（**不可逆**） |
| `chat_stream` | 普通对话，`args.onEvent=true` 走流式 |

### 4.3 流式事件（`chat_stream` 且 `onEvent:true`）

事件类型：`delta` | `reasoning` | `done` | `result` | `error` | `step` | `saved` | `deai`

---

## 5. 自动写作流水线

### 5.1 触发链路

```
用户点 dock 上的「全自动」（glue.js 注入）
  → startFull(n)
      ├─ 读 get_settings → last_state → bookId / session
      ├─ scan_tree → 求 正文/ 最大章号 latest
      └─ ipc auto_write_start {bookId, sessionId, fromCh: latest+1, toCh: latest+n, fullAuto: true}
  → 后端 tokio::spawn(auto_write_run(...))
  → glue.js 每 2s 轮询 auto_write_status → 渲染进度卡片
```

### 5.2 单章流程（`auto_write_run` 内）

```
1) 细纲     细纲/细纲_第N章.md 不存在 → 用 outline 角色生成并落盘（≤300 字：目标/冲突/看点/钩子）
2) 正文     chapter 角色生成，system 里注入 auto_book_context()
3) 审核     review 角色（temp 0.2、max 1500、no_thinking）→ 5 条标准
            发现问题 → 按意见重写一轮（最多 1 轮）
4) 去AI味   机器门 score_text() 评分，PASS_SCORE = 32.0（0=人味，100=AI味）
            未过 → 按命中项改写，最多 2 轮
5) 写入     fullAuto → 正文/第N章.md（approved）
            否则     → 正文待审/第N章.md（pending，需人工审）
6) 章后处理 人物表状态回写 / 伏笔台账更新 / 每 5 章滚动前情摘要 / 每 10 章一致性体检
7) 进度     每步 auto_log(ch, step, text) + persist_auto_task()
```

**实测数据**（3 章连跑，历史题材）：`2290 / 3428 / 2987 字`，去AI味 `14 / 14 / 6 分`（全部 ≤32 通过），审核全部通过，总耗时约 4 分钟。

### 5.3 上下文注入层级（`auto_book_context`）

每章动笔前注入（顺序即优先级）：

| 层 | 内容 | 预算 |
|---|---|---|
| L0 | 建书档案（`smart_archive` 智能截取，保卷框架/伏笔/结局） | 动态 |
| L0.5 | **分卷细纲**（`细纲/` 里文件名含「卷」的文件） | 1500 字 |
| L1 | 人物表 | 2400 字 |
| L1 | 前情摘要（滚动更新） | 1800 字 |
| L1 | **伏笔台账**（未回收的不要提前揭底） | 1500 字 |
| L2 | 本章细纲（规定节拍，必须逐条落实） | 全量 |
| L2 | 最近正文·上一章结尾（衔接参考） | 截取 |
| — | **长篇一致性红线**（6 条，违反即算失败） | 固定 |

红线内容（改提示词时不要删）：
1. 只写本章细纲规定的节拍，不自由发挥
2. 不提前揭底未回收的伏笔
3. 不新增档案/人物表以外的重要人物或设定
4. 姓名、身份、称呼、能力、伤势、位置必须与人物表/伏笔台账/上一章结尾一致
5. 时间线从上一章结尾接着走，不复述前文
6. 上一章已解决的冲突不重复解决；已回收的伏笔不再使用；宁可留白

### 5.4 自动审核标准（`review_and_fix_chapter`）

注入：本章细纲 + 人物表 + 伏笔台账 + 前情摘要 + 上一章结尾 + 待审正文。检查项：
1. 设定冲突 / 人物言行不一致 / 时间线错乱 / 前后矛盾 / 称呼错误
2. 与细纲偏离
3. 文风与人设一致性
4. **跑偏检查**：是否写了细纲以外剧情、提前揭底、新增档案外人物、重复解决冲突
5. **时间线是否紧接上一章**、有没有复述前文凑字数

### 5.5 智能体角色

`molan_llm::resolve_agent_channel(db, "<role>")`：

| role | 参数 | 用途 |
|---|---|---|
| `outline` | temp 0.6, max 8000 | 细纲生成 |
| `chapter` | temp 0.7 | 正文生成 |
| `review` | temp 0.2, max 1500, `no_thinking: true` | 审核 |
| `summary` | — | 前情摘要 / 体检 |

可在设置页 `agent_profile__<task>` 里覆盖渠道。

---

## 6. 进度可见性架构（本轮重点）

### 6.1 问题

React 前端**不轮询 `list_messages`、不暴露 store**，所以后端写进 DB 的进度消息（`【全自动】第N章 已写入…`）只有刷新页面才出现。用户因此以为"没有自动写"。

### 6.2 方案：后端日志 + 前端自渲染

**后端**（`handlers/stream.rs`）：
```rust
static AUTO_LOGS: Mutex<Vec<Value>> = Mutex::new(Vec::new());
static AUTO_LOG_BOOK: Mutex<String> = Mutex::new(String::new());

fn auto_log_clear(book_id: &str)   // 任务开始时清空并记录归属书
fn auto_log(ch: i64, step: &str, text: impl Into<String>)  // 每步追加，上限 300 条
fn auto_logs_for(book_id: &str) -> Vec<Value>  // ★ 只返回属于该书的日志
```
`auto_write_status` 三处返回都改用 `auto_logs_for(&book_id)`——**否则 A 书的进度卡片会显示在 B 书的对话里**。

日志条目：`{"ts": 毫秒, "ch": 章号, "step": "start|chapter|outline|review|deai|write|skip|stop|done|error", "text": "人话"}`。

**前端**（`glue.js`）：轮询 `auto_write_status`（2s）→ 在对话滚动区渲染 `.wxfeed` 卡片。

### 6.3 卡片规格

```
● 全自动生成 · 第 2/3 章                          [停止]
▶ 开始：第1~3章 · 全自动（审核 → 去AI味 → 写入正文）
✓ 第1章 开始生成
● 第1章 审核中…          ← 正在跑的那一步是脉冲红点
✓ 第1章 审核：通过
✓ 第1章 去AI味：14分/过（1项·skill:f4bee74b-…）
✓ 第1章 已写入 正文/第1章.md（2290字）
…
```
- 运行中：标题带脉冲红点 + 「停止」按钮
- 结束：标题变「已完成 / 已停止 / 失败」+「关闭」按钮
- 已完成且最后一条日志超过 30 分钟 → 不再显示（避免旧卡片常驻）
- 按书过滤（`s.bookId !== st.bookId` 直接不显示）

### 6.4 硬性安全规则（血泪教训）

> **不要在 MutationObserver 回调里重挂已连接的节点。**

初版实现里有这么一行：
```js
else if (host.lastElementChild !== feedEl) host.appendChild(feedEl);
```
配合 `MutationObserver(...).observe(document.body, {childList:true, subtree:true})`，一旦该条件持续为真就会形成
`appendChild → 突变 → 回调 → appendChild …` 的微任务死循环，**页面在 HTML 解析阶段就卡死，白屏且 DOMContentLoaded 永不触发**。

现在 `renderFeed` 的写法（照抄即可）：
```js
const renderFeed = () => {
  if (feedScheduled || feedBroken) return;      // 防重入
  feedScheduled = true;
  setTimeout(() => {                             // 防抖，一帧只渲一次
    feedScheduled = false;
    try { mountFeed(); } catch (e) { feedBroken = true; }   // 出错自毁，绝不拖垮页面
  }, 60);
};
```
`mountFeed()` 内部：
- 节点还在 → **只更新内容，绝不 append**
- 节点被 React 清掉 → 重建，但**每秒最多重建一次**（`feedLastMount` 节流）
- 写文本前先比较：`if (el.textContent !== s) el.textContent = s;`

另外 `installAutoStudio()` / `installAutoDock()` 调用点都包了 `try/catch`，注入层任何异常都不允许影响主应用。

---

## 7. 前端注入层规范（改 UI 必读）

### 7.1 常用 DOM 选择器

| 区域 | 选择器 |
|---|---|
| 会话滚动区 | `main.chat > .msgscroll`（消息：`.usermsg` / `.aimsg`） |
| 头部消息数 | `.chathead__msgcount` |
| 输入坞工具栏 | `.dock > .dock__toolbar`（**有 `overflow:hidden`**） |
| 官方章节按钮组 | `.dock__toolbar > .dock__chapter-actions`（内含 `button.dock__next` + `button.dock__next--more`） |
| 输入框 | `textarea.dock__textarea` |
| 侧栏 | `.srail__card` / `.srail__card-name` / `.srail__sect` |
| 设置页 | `.set`（我们的面板：`.set.__wx_auto_active`、`#__wx_auto_page`） |
| 我们注入的节点 | `#__wx_auto_dockwrap`（按钮组）、`.dock__automenu`（菜单）、`#__wx_auto_feed`（进度卡片） |

### 7.2 样式复用规则

- **必须复用官方 class**，才能保证视觉与主题一致：按钮用 `dock__next`，容器用 `dock__chapter-actions is-busy`，标签用 `dock__chapter-label`。
- `is-busy` 不是装饰：官方 CSS 有
  ```css
  .dock__toolbar[data-layout=compact] .dock__chapter-actions:not(.is-busy){display:none}
  ```
  少了 `is-busy`，分栏（窄栏）时我们的按钮会**整组消失**。
- 窄栏（`data-layout=compact|icons`）下官方会：
  ```css
  .dock__chapter-actions.is-busy .dock__next{width:34px;padding:0;justify-content:center}
  .dock__chapter-actions.is-busy .dock__chapter-label{display:none}
  ```
  → 按钮变成 34×34 纯图标。这是官方设计，如需强制显示文字，加自己的 CSS 覆盖。

### 7.3 菜单/浮层定位

`.dock__toolbar{overflow:hidden}` 会把子节点菜单**裁掉**（Playwright 会误报 `is_visible: true`，肉眼却看不见）。正确做法：
```js
menu.className = 'dock__automenu';           // position: fixed
document.body.appendChild(menu);             // 挂 body，不挂 toolbar
const r = btnEl.getBoundingClientRect();
menu.style.left = Math.round(r.left) + 'px';
menu.style.bottom = Math.round(window.innerHeight - r.top + 8) + 'px';
```

### 7.4 页面级布局补丁

分栏 / 输入框高度这类**不属于自动写作**的补丁放在 `web/molan-ui-patch.js`（`C:\Users\17213\Documents\dsh-work\dsh\molan-ui-patch.js`），由 `molan-split-inject.py` 幂等地把
`<style id="molan-split-css">` + `<script src="/molan-ui-patch.js" defer>` 注入 `web/index.html`。已实现：
- 选区→对话 浮动按钮 `#molan-sel2chat`
- 对话/编辑器 拖拽分栏 `#molan-splitbar`（`localStorage['molan_split_ratio']`）
- 输入框高度拖拽 `#molan-dockh`（`localStorage['molan_dock_height']`）

分栏核心 CSS：
```css
@media (min-width: 900px){
  .centerstage .editorpane.is-open{ position: relative; inset: auto; flex: 0 0 50%; width: 50%;
    transform: none; opacity: 1; pointer-events: auto; border-left: 1px solid var(--c-border-3); }
}
```

---

## 8. 数据与存储

### 8.1 目录

```
/vol2/1000/molan-books/books/<bookId>/
├─ 设定/   建书档案.md 人物表.md 伏笔台账.md 核心设定补全.md 前情摘要.md
├─ 细纲/   细纲_第N章.md 细纲_第一卷分段.md
├─ 正文/   第N章.md            ← 全自动写入（approved）
├─ 正文待审/第N章.md           ← 待审模式写入（pending）
└─ 参考/   *.md
```

### 8.2 设置项 key 约定

| key | 值 |
|---|---|
| `last_state` | JSON `{bookId, view, group, name, session}`（当前打开的书/文件/会话） |
| `book_auto_full__<bookId>` | `"1"` = 全自动写入正文；否则待审 |
| `book_humanize__<bookId>` | 去AI味技能，如 `skill:f4bee74b-…`；空则 `official:standard` |
| `book_style__<bookId>` | 文风档案 id（如 `lishi`） |
| `book_pref_pacing/emotion/dialogue__<bookId>` | `fast` / `intense` / `dense` |
| `book_body_length__<bookId>` | `standard` 等 |
| `book_support_skills__<bookId>__body\|revise` | JSON 数组，辅助技能 id |
| `agent_profile__<task>` | 智能体渠道覆盖 |
| `decompose_pending__<bookId>` | 导入拆解待确认的暂存 JSON |

**优先级**：`humanizeOverride` > `book_humanize__<bookId>` > `official:standard`（去AI味最多 2 轮）。

### 8.3 SQLite 表

`books`（含 `deleted_at` 软删）· `sessions` · `messages` · `settings` · `pending_chapter` · `auto_task` · `book_meta` · `word_stats` · `skills`。

- `pending_chapter`：`(id, book_id, ch, review_file, status, updated_at, ...)`，`status ∈ pending|approved`
- `auto_task`：`(id, book_id, session_id, from_ch, to_ch, current_ch, status, error, created_at, updated_at)`，`status ∈ running|done|stopped|failed`

---

## 9. 备份与恢复（必读）

### 9.1 文件历史快照 `versions/`

每次 `files::write_file` 覆盖已有文件时，会先写一份快照：
```
/vol2/1000/molan-books/versions/<bookId>/<group>/<文件名>/<毫秒时间戳>.json
内容：{"content": "文件全文", "note": "", "ts": 1788969703722}
```
**恢复一个文件** = 取该目录下时间戳最大的 json 的 `content` 写回 `books/<bookId>/<group>/<文件名>`。

⚠️ **只写过一次、从未被覆盖的文件没有快照**（例：自动生成的 `细纲_第N章.md`）。

### 9.2 从消息表恢复正文

自动写作把每章正文作为 assistant 消息存进 `messages`，所以**正文丢了可以从消息里捞**：
```sql
SELECT id, length(content), substr(content,1,50) FROM messages
 WHERE session_id='<sessionId>' ORDER BY id;
```

### 9.3 从 WAL 恢复被删的设置

SQLite 的 `writerx.db-wal` 保存了最近的页。**先复制三件套再操作**：
```bash
mkdir -p /vol2/molan-deploy/recover
cp -a /vol2/1000/molan-books/writerx.db* /vol2/molan-deploy/recover/
```
**按提交帧逐帧回退**（有效且通用）：
1. 解析 WAL 头（32 字节）得 `page_size`，帧大小 = `24 + page_size`
2. 每帧头 8 字节 = `(page_no, db_size_after_commit)`；`db_size != 0` 即提交帧
3. 从最后一帧往前，逐个把 WAL 截断到该帧末尾，连同 `writerx.db` 复制到临时目录后用 sqlite3 打开
4. 第一个"数据还在"的截断点就是删除前的状态 → dump 需要的行
5. 把 dump 出来的值 `INSERT ... ON CONFLICT DO UPDATE` 回线上库

### 9.4 删除操作的边界（踩过的坑）

- `purge_book` = 删目录 + `DELETE FROM books WHERE id=?`，**不可逆**。
- **任何清理脚本都必须只删除"自己显式记录下来的 id"**，绝不允许从 `last_state` / 用户数据里反推要删谁：
  ```python
  # 正确：setup 时写 /tmp/molan-temp-bid.txt，cleanup 只读它
  bid = open('/tmp/molan-temp-bid.txt').read().strip()
  if bid and bid != USER_BOOK_ID: ...删除...
  ```
  （曾经因为 `cleanup` 从 `last_state` 反推 bookId，误删了用户正在写的书；靠 §9.1/9.2/9.3 三路恢复才救回来。）
- 测试书一律命名以「可删」结尾，清理脚本按标题后缀二次校验。

---

## 10. 已知坑清单

| # | 坑 | 规避 |
|---|---|---|
| 1 | 注入代码在 MutationObserver 里重挂节点 → 页面解析阶段死循环白屏 | §6.4：防抖 + 防重入 + 重建节流 + try/catch |
| 2 | 菜单 `is_visible:true` 但肉眼看不见 | toolbar `overflow:hidden` 裁剪；菜单挂 `body` + `position:fixed` |
| 3 | 分栏后自定义按钮整组消失 | 容器必须带 `is-busy` class |
| 4 | Playwright `wait_until='networkidle'` 永久超时 | 前端 2s 轮询让网络永不 idle → 用 `domcontentloaded` + `wait_for_timeout` |
| 5 | Playwright 点击元素挂起 >600s | 元素在 React 重渲染中被替换；改用 `page.evaluate(() => el.click())` |
| 6 | 刚 `goto` 就断言可见 → 失败 | React 挂载需 ~5s，等 8~10s |
| 7 | Python 读 NAS 中文 stdout 崩 | `encoding='utf-8', errors='replace'` |
| 8 | plink 单行带括号/中文的命令报 `Argument expected for the -c option` | 上传 `.py`/`.sh` 再执行 |
| 9 | 日志没按书过滤 → 进度卡片串书 | `auto_logs_for(book_id)`（§6.2） |
| 10 | `purge_book` 后 `books` 行有时残留 | 清理脚本补 `DELETE FROM books/sessions/messages/pending_chapter/auto_task/settings` |
| 11 | 部署脚本返回 `[exit code: 1]` | 无害；看 "✅ 完成 / 健康检查通过" |
| 12 | 前端资源缓存 | 已是 `no-store`，刷新即可 |

---

## 11. 验证方法（改完必做）

### 11.1 后端链路（无浏览器）

上传一个 Python 脚本到 NAS，直接打 IPC：
```python
r = ipc('auto_write_start', {'bookId': tmp_bid, 'sessionId': '', 'fromCh': 1, 'toCh': 3, 'fullAuto': True})
while ...:  # 每 5s 轮询 auto_write_status，打印 logs
```
断言：每章都有 `write` 日志；`正文/第N章.md` 存在；`正文待审/` 为空；`pending_chapter.status='approved'`；`auto_task.status='done'`。

### 11.2 前端（Playwright，本机）

Python 环境：`C:\Users\17213\AppData\Local\hermes\hermes-agent\venv\Scripts\python.exe`

```python
page.goto('http://192.168.31.180:17381/', wait_until='domcontentloaded', timeout=60000)
page.wait_for_timeout(9000)          # 等 React 挂载
page.evaluate("() => document.querySelector('#__wx_auto_dockwrap .dock__next--more').click()")
page.evaluate("() => document.querySelector('.dock__automenu [data-act=\"3\"]').click()")
# 每 5s 采样 #__wx_auto_feed：存在/可见/标题/行数/最后一行/停止按钮
```
断言：卡片 5s 内出现；行数随时间增加；点 `.wxfeed__stop` 后任务变 `stopped`；点 `.wxfeed__close` 后卡片消失；`pageerror` 为空。

### 11.3 测试数据隔离

用**临时书**（复制真实书的 `设定/` + `细纲/` 和 `book_*` 设置，`last_state` 指向它），跑完清理。清理脚本严格遵守 §9.4。

---

## 12. 常见修改怎么做

### 12.1 给进度卡片加一行信息
1. 后端：在对应步骤加 `auto_log(ch, "step", "文案")`（`stream.rs`）
2. 前端：`glue.js` 的 `stepIcon()` 决定图标；卡片会自动多一行
3. 部署 + §11.1 验证

### 12.2 改提示词 / 加审核项
- 上下文：`auto_book_context()`（`stream.rs` 约 730 行起）
- 审核：`review_and_fix_chapter()`（约 2965 行起）
- 一致性红线：搜索 `【长篇一致性红线`
- 改完必须跑一次 3 章连跑，检查章节衔接与伏笔台账

### 12.3 加一个新的 dock 按钮
参照 `installAutoDock()`：
```js
wrap.className = 'dock__chapter-actions is-busy';   // 必须
const b = document.createElement('button');
b.className = 'dock__next';                          // 必须
b.innerHTML = '<svg …/>' + '<span class="dock__chapter-label">我的按钮</span>';
const anchor = toolbar.querySelector('.dock__chapter-actions');
if (anchor) anchor.insertAdjacentElement('afterend', wrap); else toolbar.appendChild(wrap);
```

### 12.4 加设置项
```js
await ipc('set_setting', { key: 'book_xxx__' + bookId, value: '1' });
```
后端用 `get_setting(db, &format!("book_xxx__{}", book_id))` 读。

---

## 13. 当前状态快照（2026-09-10）

- 二进制 11,751,320 字节；备份 `molan-server.bak.20260910-011330`
- 已验证：页面正常加载零报错；进度卡片实时刷新；停止/关闭可用；日志按书隔离
- 已验证：3 章连跑（2290/3428/2987 字，去AI味 14/14/6 分，全部审核通过、写入正文）
- 已验证：防跑偏（第 2、3 章开头分别紧接上一章结尾；伏笔台账自动登记 16 条，其中 1 条自动标记「已回收·第3章」）
- 遗留：`recover_interrupted_auto_tasks` 是空实现（容器重启后运行中任务不会自动恢复，只能手动 `auto_write_resume`）；`main.rs` 的 `t0` 未使用（仅告警）
